  

package com.example.ars.utils;

public interface PermissionRequestCodes {
    int DOWNLOADS = 4444;
}
