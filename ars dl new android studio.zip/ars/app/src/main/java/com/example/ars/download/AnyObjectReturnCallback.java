  

package com.example.ars.download;

public interface AnyObjectReturnCallback {
    void onClicked(Object object);
}
